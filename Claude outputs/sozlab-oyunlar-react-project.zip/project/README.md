# SözLab — Oyunlar

Pixel-accurate React + Tailwind CSS recreation of the SözLab "Oyunlar" (Games) screen.

## Run it

```bash
npm install
npm run dev
```

Then open the printed local URL (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview
```

## Structure

```
src/
  App.jsx                        — top-level layout (background + header + sidebar + main)
  main.jsx                       — React entry point
  index.css                      — Tailwind directives + small global resets
  data/games.js                  — nav items, bottom-nav items, and the 17 game cards' content/theme data
  components/
    Header.jsx                   — logo, search bar, streak/XP badges, avatar
    Sidebar.jsx                  — nav list, daily-mission card, decorative trophy
    MainContent.jsx              — page title + the games grid + bottom nav + corner note
    GameCard.jsx                 — one game tile (icon, badge, title, description, XP, button)
    BottomNav.jsx                — the floating mobile-style bottom navigation bar
    DecorativeBackground.jsx     — the low-poly constellation lines + corner crystal shapes
```

Each game card's colors (border, glow, badge, icon gradient, button gradient) come from the
`THEMES` map in `src/data/games.js` — add a new game by adding one object to the `GAMES` array
with an existing (or new) `theme` key.

## Notes

- Icons are emoji rather than custom illustrations, to keep the project dependency-free.
- The layout is pixel-matched at desktop width (~1787px, the size of the reference design) and
  degrades gracefully on tablet/mobile (sidebar hides below `lg`, the grid drops to 2 columns
  below `md`, the corner note hides below `xl`).

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        cursive: ['Kalam', 'cursive'],
      },
    },
  },
  plugins: [],
};

import { BOTTOM_NAV } from '../data/games.js';

export default function BottomNav() {
  return (
    <div className="mt-3 flex justify-center overflow-x-auto">
      <div className="flex items-center gap-1 bg-[#0b0c22]/90 border border-white/10 rounded-2xl px-2.5 py-1 backdrop-blur-sm">
        {BOTTOM_NAV.map((item) => (
          <div
            key={item.key}
            className={`flex flex-col items-center gap-0.5 px-3 sm:px-4 py-1 rounded-xl cursor-pointer ${
              item.key === 'games'
                ? 'bg-gradient-to-b from-indigo-600/80 to-purple-700/70 shadow-[0_0_16px_-4px_rgba(129,140,248,0.7)]'
                : 'text-slate-300 hover:bg-white/5'
            }`}
          >
            <span className="text-base">{item.icon}</span>
            <span className="text-[11px] font-medium whitespace-nowrap">{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

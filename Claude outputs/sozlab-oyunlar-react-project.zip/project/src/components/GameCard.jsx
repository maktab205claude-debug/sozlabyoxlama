import { THEMES } from '../data/games.js';

export default function GameCard({ game }) {
  const t = THEMES[game.theme];
  const bt = THEMES[game.badgeTheme || game.theme];
  const bgClass = t.dark
    ? 'bg-gradient-to-br from-[#171208] to-[#0a0a12]'
    : 'bg-gradient-to-br from-[#12132c] to-[#0a0b1e]';

  return (
    <div
      className={`relative rounded-2xl border ${t.border} ${t.ring} ${t.glow} ${bgClass} p-3 flex flex-col justify-between min-h-[100px] transition-all duration-200 hover:-translate-y-0.5`}
    >
      <div className="flex items-start justify-between">
        <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${t.iconBg} flex items-center justify-center text-base shadow-lg`}>
          {game.icon}
        </div>
        <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full border ${bt.badgeBg} ${bt.badgeBorder} ${bt.badgeText}`}>
          {game.badge}
        </span>
      </div>

      <div className="mt-1.5">
        <div className="font-bold text-[13px] leading-tight">{game.title}</div>
        <div className="text-[10.5px] text-slate-400 mt-0.5 leading-snug line-clamp-2">{game.desc}</div>
      </div>

      <div className="flex items-end justify-between mt-1.5">
        <span className="text-[10.5px] font-bold text-amber-300">{game.xp}</span>
        <button className={`w-6 h-6 rounded-full bg-gradient-to-br ${t.btnBg} flex items-center justify-center text-[10px] shadow-md`}>
          →
        </button>
      </div>
    </div>
  );
}

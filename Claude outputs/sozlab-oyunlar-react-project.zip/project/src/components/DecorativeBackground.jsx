export function ConstellationBG() {
  // sadə, yüngül "low-poly" tor effekti — dekorativ fon
  const lines = [
    [0, 0, 140, 90], [140, 90, 60, 220], [0, 0, 40, 180], [40, 180, 140, 90],
    [1787 - 260, 0, 1787 - 60, 140], [1787 - 60, 140, 1787 - 160, 260], [1787 - 260, 0, 1787 - 160, 260],
    [1787 - 180, 880, 1787 - 40, 720], [1787 - 40, 720, 1787 - 160, 600], [1787 - 180, 880, 1787 - 160, 600],
  ];
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-40" viewBox="0 0 1787 880" preserveAspectRatio="none">
      {lines.map((p, i) => (
        <line key={i} x1={p[0]} y1={p[1]} x2={p[2]} y2={p[3]} stroke="#4f46e5" strokeWidth="1" opacity="0.5" />
      ))}
      {lines.map((p, i) => (
        <circle key={'a' + i} cx={p[0]} cy={p[1]} r="2.5" fill="#818cf8" />
      ))}
    </svg>
  );
}

export function CrystalBlob({ className }) {
  return (
    <svg viewBox="0 0 200 200" className={className}>
      <defs>
        <linearGradient id="crystalGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#818cf8" />
          <stop offset="100%" stopColor="#4338ca" />
        </linearGradient>
      </defs>
      <polygon points="100,10 180,70 150,180 50,180 20,70" fill="url(#crystalGrad)" opacity="0.85" />
      <polygon points="100,10 180,70 100,100" fill="#a5b4fc" opacity="0.5" />
      <polygon points="100,10 20,70 100,100" fill="#6366f1" opacity="0.6" />
      <polygon points="20,70 50,180 100,100" fill="#3730a3" opacity="0.7" />
      <polygon points="180,70 150,180 100,100" fill="#4f46e5" opacity="0.7" />
    </svg>
  );
}

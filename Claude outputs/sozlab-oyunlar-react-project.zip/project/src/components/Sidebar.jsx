import { NAV_ITEMS } from '../data/games.js';

function NavItem({ item, variant }) {
  if (variant === 'pink') {
    return (
      <div className="flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-fuchsia-600/90 to-purple-700/90 shadow-[0_0_18px_-4px_rgba(217,70,239,0.6)] cursor-pointer">
        <span className="text-lg">{item.icon}</span>
        <span className="font-semibold text-sm">{item.label}</span>
      </div>
    );
  }
  if (variant === 'active') {
    return (
      <div className="relative flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600/90 to-blue-700/80 shadow-[0_0_18px_-4px_rgba(99,102,241,0.7)] cursor-pointer">
        <span className="absolute left-0 top-1.5 bottom-1.5 w-1 rounded-full bg-white/80"></span>
        <span className="text-lg">{item.icon}</span>
        <span className="font-semibold text-sm">{item.label}</span>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-xl text-slate-300 hover:bg-white/5 cursor-pointer transition-colors">
      <span className="text-lg opacity-80">{item.icon}</span>
      <span className="text-sm">{item.label}</span>
    </div>
  );
}

export default function Sidebar() {
  return (
    <aside className="relative w-[250px] shrink-0 hidden lg:flex flex-col gap-1">
      <NavItem item={NAV_ITEMS[0]} variant="pink" />
      <NavItem item={NAV_ITEMS[1]} variant="active" />
      {NAV_ITEMS.slice(2).map((item) => (
        <NavItem key={item.key} item={item} />
      ))}

      <div className="mt-2.5 bg-gradient-to-br from-[#171034] to-[#0c0e28] border border-white/10 rounded-2xl p-3">
        <div className="flex items-start gap-3">
          <div className="text-3xl leading-none">🏆</div>
          <div>
            <div className="text-sm font-bold bg-gradient-to-r from-fuchsia-400 to-purple-400 bg-clip-text text-transparent">
              Gündəlik missiyanı tamamla!
            </div>
            <div className="text-xs text-slate-400 mt-1">+50 XP qazan və sıralamaya qalx!</div>
          </div>
        </div>
        <button className="mt-3 w-full py-2 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 text-[#2b1400] text-xs font-extrabold tracking-wide">
          MİSSİYA
        </button>
      </div>

      <div className="mt-auto flex-1 flex items-center justify-center opacity-95">
        <div className="text-[130px] leading-none drop-shadow-[0_0_35px_rgba(129,140,248,0.6)]">🏆</div>
      </div>
    </aside>
  );
}

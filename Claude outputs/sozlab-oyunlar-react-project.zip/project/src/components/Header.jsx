export default function Header() {
  return (
    <header className="flex items-center gap-2 sm:gap-3.5 bg-gradient-to-r from-[#0d0e29]/90 to-[#0a0b22]/90 border border-white/5 rounded-2xl px-3 sm:px-4 py-2 backdrop-blur-sm">
      <div className="flex items-center gap-2.5 shrink-0">
        <div className="w-9 h-9 rounded-full bg-[#150a30] border border-fuchsia-400/40 flex items-center justify-center text-lg shadow-[0_0_14px_-2px_rgba(217,70,239,0.7)]">
          🧠
        </div>
        <span className="text-xl font-extrabold tracking-tight">
          <span className="text-white">Söz</span>
          <span className="bg-gradient-to-r from-amber-300 to-yellow-500 bg-clip-text text-transparent">Lab</span>
        </span>
      </div>

      <div className="flex-1 max-w-xl hidden sm:block">
        <div className="flex items-center gap-2 bg-[#0c0d24] border border-white/10 rounded-full px-4 py-2 text-sm text-slate-400">
          <span>🔍</span>
          <span>Oyun, mövzu və ya söz axtar...</span>
        </div>
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2.5 ml-auto shrink-0">
        <div className="flex items-center gap-1.5 bg-[#160f28] border border-orange-400/30 rounded-full px-3 py-1.5 text-sm font-semibold text-orange-300">
          <span>🔥</span>
          <span>1</span>
        </div>
        <div className="flex items-center gap-1.5 bg-[#1c1508] border border-amber-400/40 rounded-full px-3 py-1.5 text-sm font-semibold text-amber-300">
          <span>⭐</span>
          <span>268 XP</span>
        </div>
        <button className="relative w-9 h-9 rounded-full bg-[#0c0d24] border border-white/10 flex items-center justify-center text-slate-300">
          🔔
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-rose-500"></span>
        </button>
        <button className="w-9 h-9 rounded-full bg-[#0c0d24] border border-white/10 hidden sm:flex items-center justify-center text-slate-300">
          🌙
        </button>
        <div className="w-9 h-9 rounded-full overflow-hidden border border-white/10 hidden sm:flex items-center justify-center bg-gradient-to-b from-sky-500 to-red-500 text-[10px]">
          🇦🇿
        </div>
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center font-bold text-sm">
          K
        </div>
      </div>
    </header>
  );
}

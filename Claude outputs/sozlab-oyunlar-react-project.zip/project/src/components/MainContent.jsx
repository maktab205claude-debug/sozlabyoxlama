import { GAMES } from '../data/games.js';
import GameCard from './GameCard.jsx';
import BottomNav from './BottomNav.jsx';

export default function MainContent() {
  return (
    <main className="relative flex-1 min-w-0">
      <div className="flex items-center gap-2 mb-1">
        <span className="text-2xl">🎮</span>
        <h1 className="text-xl font-extrabold">Oyunlar</h1>
      </div>
      <p className="text-[13px] text-slate-400 mb-2.5">Oyun seç, XP qazan, liderboardda yüksəl!</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        {GAMES.map((g, i) => (
          <GameCard key={i} game={g} />
        ))}
      </div>

      <BottomNav />

      <div className="hidden xl:block absolute right-6 bottom-24 pointer-events-none select-none text-right max-w-[220px]">
        <div className="font-cursive text-xl bg-gradient-to-r from-pink-300 via-amber-300 to-yellow-300 bg-clip-text text-transparent leading-tight drop-shadow-[0_0_10px_rgba(251,191,36,0.4)]">
          Daha çox öyrən
          <br />
          Daha çox qazan!
        </div>
      </div>
    </main>
  );
}

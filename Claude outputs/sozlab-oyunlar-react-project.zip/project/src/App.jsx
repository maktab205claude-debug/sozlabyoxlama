import Header from './components/Header.jsx';
import Sidebar from './components/Sidebar.jsx';
import MainContent from './components/MainContent.jsx';
import { ConstellationBG, CrystalBlob } from './components/DecorativeBackground.jsx';

export default function App() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-[#04050f] text-white">
      <ConstellationBG />
      <CrystalBlob className="absolute top-0 right-0 w-56 h-56 opacity-60 -translate-y-10 translate-x-10 blur-[1px]" />
      <CrystalBlob className="absolute bottom-0 right-8 w-40 h-40 opacity-50 translate-y-6" />

      <div className="relative z-10 p-3 flex flex-col gap-3 max-w-[1787px] mx-auto">
        <Header />
        <div className="flex gap-4 items-stretch">
          <Sidebar />
          <MainContent />
        </div>
      </div>
    </div>
  );
}
